﻿namespace SocialNetwork.Model
{
    public enum ContentTypes
    {
        None = 0,
        Text = 1,
        Image = 2,
    }
}