﻿namespace SocialNetwork.Model
{
    public class TextContent : BaseContent
    {
        public string Text { get; set; }
    }
}